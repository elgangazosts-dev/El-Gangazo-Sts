import React from "react";

export default function App() {
  return (
    <div style={{ padding: 20, fontFamily: "Arial" }}>
      <h1>Mi Establecimiento</h1>
      <p>Página base lista para personalizar y subir a Vercel.</p>
      <ul>
        <li>Categorías de productos</li>
        <li>Descripción de productos</li>
        <li>Ubicación</li>
        <li>Botón de WhatsApp</li>
        <li>Integración Sistecrédito y Addi (pendiente backend)</li>
      </ul>
    </div>
  );
}
